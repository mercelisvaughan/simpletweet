package com.codepath.apps.restclienttemplate;

public class TweetsAdapter {


}
